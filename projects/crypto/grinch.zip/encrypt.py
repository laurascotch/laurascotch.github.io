from Crypto.Util.number import inverse

N = 29376184821108156618286183148714771792276652929137914081529218159551556583417

E = [31337, 313337, 3133337]

# ---- Encrypt ----
with open('flag.txt', 'r') as f:
    flag = f.readline().split()[0]

x = ''
for c in flag:
    x = x + str(ord(c))

M = int(x)

ct = pow(pow(pow(M, E[0], N)+1, E[1], N)+1, E[2], N)

ct_file = open("encrypted.txt", 'w')
ct_file.write(str(ct))
ct_file.close()